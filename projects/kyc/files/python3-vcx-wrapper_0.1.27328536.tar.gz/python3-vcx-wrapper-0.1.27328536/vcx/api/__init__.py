"""
Api calls for Libvcx
"""