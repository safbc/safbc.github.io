## Documentation:
Requires:
* python3

 Run this commands:
```
python3 generateDocs.py
```

* A directory will be created locally `./docs` which contains subdirectories 'vcx' and within that 'api'.  Html files are generated and put here that give details on each api function.

